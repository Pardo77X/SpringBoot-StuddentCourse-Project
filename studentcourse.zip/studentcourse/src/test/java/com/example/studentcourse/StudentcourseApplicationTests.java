package com.example.studentcourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentcourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
